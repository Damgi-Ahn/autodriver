# eskf_localization

`eskf_localization`은 15-state ESKF(오차상태 15 + 공분산 15x15) 기반의 로컬라이제이션 노드입니다.

현재 운영 정책은 “yaw는 IMU gyro 전파가 기본, GNSS/차량 측정은 업데이트로 보정”이며,
GNSS 상태(status=-1/0/1/2) 기반의 안전 장치와 강건성(NIS gate inflate)을 포함합니다.

핵심 키워드
- 15-state ESKF: `p, v, q, b_g, b_a` + covariance `P`
- Propagation: IMU gyro(각속도) 기반 자세 전파, IMU accel은 전파 입력에서 배제(a=0)
- Update: GNSS position, GNSS velocity, GNSS heading yaw(GPHDT), OBD speed(+NHC/ZUPT), steer yaw-rate로 gyro bias 제약
- Robustness: NavSatFix status=-1 하드 드랍, status 복구 홀드오프, NIS gate 초과 시 skip 대신 R inflate

---

## Data Flow (High Level)

```mermaid
flowchart LR
  imu_raw["imu_raw (sensor_msgs/Imu)"] --> imu_pre["IMU Preprocessor"]
  imu_pre --> imu_pub["/sensing/imu/imu_data (sensor_msgs/Imu)"]
  imu_pre -->|omega, dt| propagate["ESKF Propagate (gyro)"]

  navsatfix["navsatfix (NavSatFix)"] --> gnss_pre["GNSS Preprocess (projection + lever-arm)"]
  map_proj["map_projector_info"] --> gnss_pre
  gnss_pre --> gnss_pos["GNSS Position Update"]

  gnssvel["gnss_vel (TwistStamped: ve, vn)"] --> gnss_vel["GNSS Velocity Update"]
  gphdt["heading (GPHDT)"] --> arb["Heading Arbitrator"]
  navsatfix --> arb
  arb --> yaw_upd["Yaw Update (scalar)"]

  vel_obd["vehicle velocity (OBD)"] --> veh_upd["Vehicle Constraints Update"]
  steer["vehicle steering"] --> yawrate_upd["Yaw Rate Bias Update"]

  propagate --> state["ESKF State"]
  gnss_pos --> state
  yaw_upd --> state
  gnss_vel --> state
  veh_upd --> state
  yawrate_upd --> state

  state --> odom["/localization/kinematic_state (Odometry)"]
  state --> tf["TF map->base_link"]
  state --> diag["/diagnostics"]
  gnss_pre --> gnss_odom["/localization/kinematic_state_gnss (Odometry)"]
```

---

## 상태(State) / 출력(Output)

### ESKF 상태벡터(명목 + 바이어스)
- `p_map (3)`: map 좌표계 위치 [m]
- `v_map (3)`: map 좌표계 속도 [m/s]
- `q_map_from_base`: 자세 quaternion (실차에서는 yaw가 핵심, roll/pitch는 출력에서 평탄화 가능)
- `b_g (3)`: gyro bias [rad/s]
- `b_a (3)`: accel bias [m/s^2]

### 출력 벡터(주로 Odometry)
- `nav_msgs/Odometry`: pose(위치/자세) + twist(속도)
- 선택적으로 `output.flatten_roll_pitch=true`이면 roll/pitch를 0으로 만들고 분산을 크게 부여합니다.

---

## ROS I/O

### Subscribe
- IMU raw: `imu_topic` (default: `/sensing/imu/imu_raw`) `sensor_msgs/msg/Imu`
- GNSS fix: `gnss_topic` (default: `/sensing/gnss/navsatfix`) `sensor_msgs/msg/NavSatFix`
- GNSS heading: `heading_topic` (default: `/sensing/gnss/heading`) `skyautonet_msgs/msg/Gphdt`
- GNSS velocity: `gnss_vel_topic` (default: `/sensing/gnss/vel`) `geometry_msgs/msg/TwistStamped`
- Map projector: `map_projector_info_topic` (default: `/map/map_projector_info`) `tier4_map_msgs/msg/MapProjectorInfo`
- Vehicle velocity: `velocity_topic` (default: `/vehicle/status/velocity_status`) `autoware_vehicle_msgs/msg/VelocityReport`
- Vehicle steering: `steering_topic` (default: `/vehicle/status/steering_status`) `autoware_vehicle_msgs/msg/SteeringReport`
- TF: `/tf`, `/tf_static` (imu/gnss frame ↔ base_link extrinsic)

### Publish
- ESKF odom: `output_odom_topic` (default: `/localization/kinematic_state`) `nav_msgs/msg/Odometry`
- GNSS odom (시각화/디버그): `/localization/kinematic_state_gnss` `nav_msgs/msg/Odometry`
- Preprocessed IMU: `/sensing/imu/imu_data` `sensor_msgs/msg/Imu`
- GNSS speed (GNSS vel에서 생성): `/sensing/gnss/velocity_status` `autoware_vehicle_msgs/msg/VelocityReport`
- Diagnostics: `/diagnostics` `diagnostic_msgs/msg/DiagnosticArray`
- TF: `map -> base_link` (`publish_tf=true`일 때)

프레임 규약:
- `header.frame_id = map` (`map_frame`)
- `child_frame_id = base_link` (`base_frame`)

---

## 운영 정책(중요)

### 1) IMU accel은 전파에 사용하지 않습니다
- 전파 입력은 gyro(각속도) 기반이며, IMU accel은 전파 입력에서 항상 a=0이 되도록 처리합니다.
- 이유: 실차에서 IMU accel 신뢰도가 낮고, 차량 속도/제약 업데이트가 종방향/횡방향 안정화에 더 효과적입니다.

### 2) GNSS status 기반 yaw 정책(핵심)
- `status < 0` (예: -1): GNSS 관련 값은 즉시 모두 무시(하드 드랍)
- GPHDT(heading 토픽) yaw 업데이트:
  - `heading.min_gnss_status_for_yaw_update` 이상에서만 사용(기본 1)
  - 0->good 전환 시 `heading.arb.gphdt_recover_holdoff_sec` 동안 추가 홀드오프(기본 2.5s, 런치에서 조절)
### 3) NIS gate 동작: skip 대신 R inflate(기본)
- update에서 NIS가 gate를 초과하면 measurement를 버리는 대신 `R_eff = R * factor`로 inflate 후 업데이트를 진행합니다.
- 목표: 일시적 발산/점프 구간에서 “복구 불가” 상태가 되지 않도록 완화.

---

## 파라미터 레퍼런스(ROS2 parameters)

### 0) 파라미터를 어디서 조절하나

- 파라미터 선언/키 목록: `ros/src/skyautonet/localization/eskf_localization/src/parameters.cpp`
- 코드 기본값(정책/튜닝 기본): `ros/src/skyautonet/localization/eskf_localization/include/eskf_localization/parameters.hpp`,
  `ros/src/skyautonet/localization/eskf_localization/include/eskf_localization/eskf/eskf_core.hpp`,
  `ros/src/skyautonet/localization/eskf_localization/include/eskf_localization/types.hpp`,
  `ros/src/skyautonet/localization/eskf_localization/include/eskf_localization/preprocess/imu_preprocessor.hpp`,
  `ros/src/skyautonet/localization/eskf_localization/include/eskf_localization/preprocess/gnss_heading_arbitrator.hpp`
- 런치에서 기본으로 덮어쓰는 항목(운영 튜닝): `ros/src/skyautonet/localization/eskf_localization/launch/eskf_localization.launch.xml`

우선순위는 “런치/CLI override 값”이 있으면 그것이 적용되고, 없으면 “코드 기본값”이 적용됩니다.

### 1) 런치에서 조절하는 파라미터(운영 튜닝)

아래 항목은 기본 런치에서 노출되어 있으며, 현장 튜닝 가능성이 높은 것만 남겨둔 목록입니다.

| Parameter | Type | Launch Default | 설명 |
|---|---:|---:|---|
| `init_imu_calibration` | bool | `true` | true면 런타임 IMU 캘리브레이션 수행(정지 필요), false면 파일 로드 |
| `imu.gyro_lpf_cutoff_hz` | double | `10.0` | gyro LPF cutoff [Hz] (↑: 반응↑/노이즈↑, ↓: 부드러움↑/지연↑) |
| `gnss.covariance_scale` | double | `25.0` | GNSS covariance 스케일(↑: GNSS 영향↓, ↓: GNSS 영향↑) |
| `gnss.pos_inflate_status_fix` | double | `1000000.0` | status==0 구간 GNSS 위치 분산 inflate |
| `gnss.pos_inflate_status_sbas` | double | `100.0` | status==1 구간 GNSS 위치 분산 inflate |
| `gnss.vel_inflate_status_fix` | double | `25.0` | status==0 구간 GNSS 속도 분산 inflate |
| `gnss.vel_inflate_status_sbas` | double | `4.0` | status==1 구간 GNSS 속도 분산 inflate |
| `heading.arb.gphdt_recover_holdoff_sec` | double | `2.5` | status 복구 직후 GPHDT yaw 사용 홀드오프 [s] |
| `vehicle.enable_zupt` | bool | `true` | ZUPT(v_base.x≈0) 활성화 (OBD 정지 후보 + PVT 속도 1km/h 미만일 때만 적용) |
| `vehicle.zupt_speed_threshold_mps` | double | `0.2` | 정지 판단 기준 속도 [m/s] |
| `vehicle.zupt_var` | double | `0.01` | ZUPT 분산((m/s)^2) |
| `vehicle.enable_nhc` | bool | `true` | NHC(v_base.y≈0, v_base.z≈0) 활성화 |
| `vehicle.nhc_var` | double | `4.0` | NHC 분산((m/s)^2) |

### 2) 그 외 파라미터(기본값 유지 권장, 필요 시만 조절)

기본 런치에는 노출하지 않았지만 ROS2 parameter로는 존재합니다. 필요하면 런치에 `<param>`를 추가하거나,
정책으로 고정할 값이면 코드 기본값(헤더)을 조정하는 방식으로 관리합니다.

- I/O / Frame / Publish: `imu_topic`, `gnss_topic`, `heading_topic`, `map_projector_info_topic`, `velocity_topic`, `steering_topic`, `output_odom_topic`, `map_frame`, `base_frame`, `publish_tf`, `publish_rate` (기본값: `types.hpp`)
- Time alignment: `time_alignment_tolerance_ms` (기본값: `parameters.cpp`에서 2.0ms)
- IMU calibration / preprocessing: `calibration_file_path`, `imu.accel_lpf_cutoff_hz`, `imu.gravity_magnitude`, `imu.enable_gravity_removal`, `imu.enable_orientation_calibration` (기본값: `imu_preprocessor.hpp`, `parameters.cpp`)
- GNSS updates / covariance handling: `enable_gnss_pos_update`, `enable_gnss_vel_update`, `gnss.use_navsatfix_covariance`, `gnss.pos_var_*`, `gnss.vel_var_*`, `gnss.pos_cov_diag_only`, `gnss.min_status_for_pos_update` (기본값: `parameters.hpp`)
- Heading: `heading.enable_yaw_update`, `heading.yaw_var`, `heading.max_rate_radps`, `heading.arb.max_time_diff_sec`, `heading.min_gnss_status_for_yaw_update` (기본값: `parameters.hpp`, `gnss_heading_arbitrator.hpp`)
- Vehicle constraints / geometry: `wheelbase`(기본 7.0m), `vehicle.enable_speed_update`, `vehicle.speed_use_abs`, `vehicle.speed_var`, `vehicle.min_speed_mps_for_speed_update`, `vehicle.enable_yaw_rate_update`, `vehicle.yaw_rate_*` (기본값: `types.hpp`, `parameters.hpp`)
- ESKF core (covariance / noise / gating): `eskf.init_*`, `eskf.*_noise_std`, `eskf.nis_gate_*`, `eskf.max_correction_*`, `eskf.use_so3_jacobian_reset` (기본값: `eskf_core.hpp`)
- Output shaping: `output.flatten_roll_pitch`, `output.roll_pitch_var` (기본값: `parameters.hpp`)

---

## 파일/코드 위치(빠른 링크)
- 노드 배선/토픽: `ros/src/skyautonet/eskf_localization/src/node/core.cpp`
- IMU 전처리/전파: `ros/src/skyautonet/eskf_localization/src/node/cb_imu.cpp`
- GNSS/Heading: `ros/src/skyautonet/eskf_localization/src/node/cb_gnss.cpp`
- 차량 제약(OBD/NHC/ZUPT/steer): `ros/src/skyautonet/eskf_localization/src/node/cb_vehicle.cpp`
- Heading arbitrator(상태기계): `ros/src/skyautonet/eskf_localization/src/preprocess/gnss_heading_arbitrator.cpp`
- ESKF core: `ros/src/skyautonet/eskf_localization/src/eskf/eskf_core.cpp`
